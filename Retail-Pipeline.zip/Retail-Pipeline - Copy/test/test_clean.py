"""Tests for the cleaning rules in pipeline/clean.py.

Run from the project root:   python -m pytest -v
R2 and R7 are the fiddliest rules, so they get the most tests.
Testing Procedure : assert → individual Rule 1 to Rule 8 tests → fixtures → end-to-end testing
"""
from decimal import Decimal

import pandas as pd
import pytest

from pipeline import clean as C

D = Decimal
RAW_COLS = ["Invoice", "StockCode", "Description", "Quantity",
            "InvoiceDate", "Price", "Customer ID", "Country"]


def make_raw(rows):
    """Build a raw (all-text) DataFrame like the one extract_raw() returns."""
    df = pd.DataFrame(rows, columns=RAW_COLS)
    df.insert(0, "source_sheet", "Year 2010-2011")
    df.insert(0, "raw_row_id", [f"t:{i + 2}" for i in range(len(df))])
    return df


# ------------------------------------------------------------------ R1
def test_r1_removes_exact_duplicates_only():
    same = ("1", "A", "Mug", "1", "2010-12-01 10:00:00", "1.00", "100", "UK")
    other_second = ("1", "A", "Mug", "1", "2010-12-01 10:00:01", "1.00", "100", "UK")
    kept, issues = C.r1_remove_duplicates(make_raw([same, same, other_second]))
    assert len(kept) == 2                              # a different timestamp is NOT a duplicate
    assert list(issues["raw_row_id"]) == ["t:3"]       # the second copy was logged
    assert set(issues["rule"]) == {"R1"}
    assert set(issues["action"]) == {"dropped"}


# ------------------------------------------------------------------ R2
def test_r2_cancellation_vs_negative_quantity():
    df = pd.DataFrame({
        "invoice_no": ["C536379", "536414", "536365", "C536380"],
        "quantity":   [-1,        -5,       3,        2],
    })
    out = C.r2_flag_cancellations_and_writeoffs(df)
    # Cancellation: starts with C (even if quantity is positive)
    assert list(out["is_cancellation"]) == [True, False, False, True]
    # Write-off: negative quantity on a NORMAL invoice. A C invoice is never a write-off.
    assert list(out["is_writeoff"]) == [False, True, False, False]


def test_r2_counts_are_separate_and_do_not_overlap():
    df = pd.DataFrame({
        "invoice_no": ["C1", "C2", "10", "11", "12"],
        "quantity":   [-1,   -2,   -3,   -4,   5],
    })
    out = C.r2_flag_cancellations_and_writeoffs(df)
    assert out["is_cancellation"].sum() == 2
    assert out["is_writeoff"].sum() == 2
    assert not (out["is_cancellation"] & out["is_writeoff"]).any()


def test_r2_negative_quantity_alone_is_not_a_cancellation():
    out = C.r2_flag_cancellations_and_writeoffs(
        pd.DataFrame({"invoice_no": ["536414"], "quantity": [-10]}))
    assert not out["is_cancellation"].iloc[0]
    assert out["is_writeoff"].iloc[0]


def test_r2_lowercase_c_and_spaces_still_count_as_cancellation():
    out = C.r2_flag_cancellations_and_writeoffs(
        pd.DataFrame({"invoice_no": [" c536379 "], "quantity": [-1]}))
    assert out["is_cancellation"].iloc[0]
    assert not out["is_writeoff"].iloc[0]


# ------------------------------------------------------------------ R3
def test_r3_blank_customer_gets_placeholder_and_float_ids_are_fixed():
    raw = make_raw([
        ("1", "A", "Mug", "1", "2010-12-01 10:00:00", "1.00", "13085.0", "UK"),
        ("2", "A", "Mug", "1", "2010-12-01 10:00:00", "1.00", "", "UK"),
    ])
    out = C.r3_handle_customers(C.prepare_types(raw))
    assert list(out["customer_id"]) == ["13085", C.CASH_CUSTOMER_ID]
    assert list(out["is_cash_sale"]) == [False, True]


# ------------------------------------------------------------------ R4
def test_r4_matches_stock_codes_ignoring_case():
    df = pd.DataFrame({"stock_code": ["post", "POST", "85123A", "Dot"]})
    out = C.r4_flag_non_products(df, {"POST", "DOT"})
    assert list(out["is_non_product"]) == [True, True, False, True]


# ------------------------------------------------------------------ R5
def test_r5_zero_price_is_free_sample_negative_is_flagged_for_rejection():
    df = pd.DataFrame({"unit_price": [D("0"), D("2.50"), D("-3.00")]})
    out = C.r5_check_prices(df)
    assert list(out["is_free_sample"]) == [True, False, False]
    assert list(out["is_negative_price"]) == [False, False, True]


# ------------------------------------------------------------------ R6
def test_r6_uses_exact_decimal_arithmetic():
    df = pd.DataFrame({"quantity": [3], "unit_price": [D("0.1")]})
    assert C.r6_calculate_exact_gross(df)["gross_exact"].iloc[0] == D("0.3")   # floats give 0.30000000000000004


def test_r6_rounds_only_at_the_end_half_up():
    df = pd.DataFrame({"gross_exact": [D("2.675")], "fx_rate": [D("1.0")]})
    out = C.round_money_values(df)
    assert out["gross_gbp"].iloc[0] == D("2.68")
    assert out["gross_usd"].iloc[0] == D("2.68")


# ------------------------------------------------------------------ R7
@pytest.fixture
def fx(tmp_path):
    path = tmp_path / "fx.csv"
    path.write_text("rate_date,rate\n2010-12-03,1.60\n2010-12-06,1.70\n")   # Friday and Monday only
    return C.load_fx_rates(path)


def lines(*timestamps):
    return pd.DataFrame({
        "line": range(len(timestamps)),
        "invoice_date": pd.to_datetime(list(timestamps)),
    })


def test_r7_weekend_uses_previous_friday_rate_never_a_later_one(fx):
    out = C.r7_attach_exchange_rates(lines(
        "2010-12-03 09:00:00",    # Friday   -> its own rate
        "2010-12-04 12:00:00",    # Saturday -> Friday's rate
        "2010-12-05 23:59:00",    # Sunday   -> Friday's rate (time of day is ignored)
        "2010-12-06 08:00:00",    # Monday   -> Monday's own rate
    ), fx)
    assert list(out["fx_rate"]) == [D("1.60"), D("1.60"), D("1.60"), D("1.70")]
    assert list(out["fx_rate_date"].dt.strftime("%Y-%m-%d")) == [
        "2010-12-03", "2010-12-03", "2010-12-03", "2010-12-06"]


def test_r7_keeps_every_row_and_original_order(fx):
    out = C.r7_attach_exchange_rates(lines(
        "2010-12-06 08:00:00", "2010-12-03 09:00:00", "2010-12-04 12:00:00"), fx)
    assert len(out) == 3                              # a plain join would lose weekend rows
    assert list(out["line"]) == [0, 1, 2]             # order restored after the as-of join
    assert list(out["fx_rate"]) == [D("1.70"), D("1.60"), D("1.60")]


def test_r7_errors_when_no_earlier_rate_exists(fx):
    with pytest.raises(ValueError):
        C.r7_attach_exchange_rates(lines("2010-12-01 10:00:00"), fx)   # before the first rate in the file


def test_r7_rejects_duplicate_fx_dates(tmp_path):
    path = tmp_path / "fx.csv"
    path.write_text("rate_date,rate\n2010-12-03,1.60\n2010-12-03,1.61\n")
    with pytest.raises(ValueError):
        C.load_fx_rates(path)


def test_r7_fx_file_must_have_rate_date_and_rate_columns(tmp_path):
    path = tmp_path / "fx.csv"
    path.write_text("date,gbp_usd\n2010-12-03,1.60\n")
    with pytest.raises(KeyError):                     # clean.py reads these two columns by name
        C.load_fx_rates(path)


# ------------------------------------------------------------------ R8
def write_country_file(tmp_path):
    path = tmp_path / "country_region.csv"
    path.write_text("Country,country,region\n"
                    "United Kingdom,United Kingdom,Europe\n"
                    "EIRE,Ireland,Europe\n"
                    "Unspecified,Unknown,Unknown\n")
    return path


def test_r8_maps_countries_and_keeps_unknown(tmp_path):
    df = pd.DataFrame({"country_raw": ["EIRE", "Unspecified", "United Kingdom"]})
    out = C.r8_add_country_and_region(df, write_country_file(tmp_path))
    assert list(out["country"]) == ["Ireland", "Unknown", "United Kingdom"]
    assert len(out) == 3                                # nothing dropped


def test_r8_errors_on_country_missing_from_mapping(tmp_path):
    with pytest.raises(ValueError):
        C.r8_add_country_and_region(pd.DataFrame({"country_raw": ["Atlantis"]}),
                                    write_country_file(tmp_path))


# ------------------------------------------------- whole pipeline (R1-R8)
def test_clean_end_to_end(tmp_path, monkeypatch):
    (tmp_path / "fx_rates_gbp_usd.csv").write_text(
        "rate_date,rate\n2010-12-03,1.60\n2010-12-06,1.70\n")
    (tmp_path / "country_region.csv").write_text(
        "Country,country,region\nUnited Kingdom,United Kingdom,Europe\n"
        "Unspecified,Unknown,Unknown\n")
    (tmp_path / "non_product_codes.csv").write_text("stock_code\nPOST\nB\n")
    monkeypatch.setattr(C, "REF_DIR", tmp_path)

    uk = "United Kingdom"
    raw = make_raw([
        ("536365", "85123A", "Light", "6", "2010-12-03 08:26:00", "2.55", "17850", uk),   # normal Friday sale
        ("536365", "85123A", "Light", "6", "2010-12-03 08:26:00", "2.55", "17850", uk),   # exact duplicate (R1)
        ("C536379", "85123A", "Light", "-1", "2010-12-06 09:41:00", "2.55", "17850", uk), # cancellation (R2)
        ("536414", "22139", "Damaged", "-5", "2010-12-06 10:00:00", "0", "", uk),         # write-off, free, cash sale
        ("536420", "post", "POSTAGE", "1", "2010-12-04 11:00:00", "18.00", "", uk),       # postage on a Saturday
        ("A563186", "B", "Adjust bad debt", "1", "2010-12-06 12:00:00", "-11062.06", "", uk),  # negative price (R5)
        ("536430", "21212", "Pack", "2", "2010-12-06 13:00:00", "1.00", "20000.0", "Unspecified"),
    ])
    fact, issues, stats = C.clean(raw)

    assert stats["rows_read"] == 7
    assert stats["r1_duplicates_removed"] == 1
    assert stats["r2_cancellation_lines"] == 1
    assert stats["r2_negative_qty_not_cancellation"] == 1
    assert stats["r3_cash_sale_lines"] == 3                 # write-off, postage and bad-debt rows
    assert stats["r4_non_product_lines"] == 2               # post (any case) and B
    assert stats["r5_free_sample_lines"] == 1
    assert stats["r5_negative_price_rejected"] == 1
    assert stats["r4_and_r5_negative_overlap"] == 1
    assert stats["r7_rows_before_fx"] == stats["r7_rows_after_fx"] == 5
    assert stats["r7_rows_using_earlier_rate"] == 1         # the Saturday postage line
    assert stats["r8_unknown_country_lines"] == 1
    assert stats["fact_rows"] == 5
    assert stats["distinct_customers_excl_cash"] == 2
    assert stats["total_gbp_all_lines"] == "32.75"
    assert stats["total_gbp_product_only"] == "14.75"
    assert stats["total_usd_all_lines"] == "52.34"
    assert stats["total_usd_product_only"] == "23.54"
    assert stats["issues_per_rule"] == {"R1": 1, "R2": 2, "R3": 3, "R4": 2, "R5": 2, "R8": 1}

    # nothing disappears without a log entry
    assert "t:7" in set(issues.loc[issues["rule"] == "R5", "raw_row_id"])   # rejected row is logged
    assert len(fact) + 1 + 1 == stats["rows_read"]                          # fact + duplicate + rejected
