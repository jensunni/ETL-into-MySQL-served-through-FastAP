""" Part 1: EXTRACT RAW DATA """
import json
from pathlib import Path
import pandas as pd

# 1. Finding Project folder using Dynamic path allocation
ROOT = Path(__file__).resolve().parent.parent

# 2. Excel sheet names
SHEET_TAGS = { "Year 2009-2010": "2009_10" , "Year 2010-2011": "2010_11" }


# 3. Find the Excel file
def find_workbook():

    folder = ROOT / "data" / "raw"

    if folder.exists():
        # Open Excel file in the folder
        excel_file = next(folder.glob("*.xlsx"), None)

        # If an Excel file is found, return its path
        if excel_file is not None:
            return excel_file

    raise FileNotFoundError("Excel File not found!")


# 4. Extract raw data
def extract_raw():

    # Find workbook
    workbook = find_workbook()

    # Read all Excel sheets as text
    sheets = pd.read_excel(workbook, sheet_name=None, dtype=str, keep_default_na=False)

    # Check above sheets if not found, raise error
    for sheet_name in SHEET_TAGS:

        if sheet_name not in sheets:
            raise ValueError(f" Missing sheet: {sheet_name} ")

    # Store DataFrames and row counts
    all_data = []
    row_counts = {}

    # Create the "store" folder if it doesn't exist
    STORE_DIR = ROOT / "data" / "store"

    STORE_DIR.mkdir(parents=True, exist_ok=True)

    # Process each sheet
    for sheet_name, tag in SHEET_TAGS.items():

        df = sheets[sheet_name].copy()

        # Add new column namded "source_sheet" with the sheet name as its value at 0th index
        df.insert(0, "source_sheet", sheet_name)

        # Create row IDs corresponding to Excel row numbers (starting from 2)
        row_ids = []

        # Generates id like "2009_10:2", "2009_10:3", etc. for each row in the DataFrame
        for i in range(len(df)):
            row_ids.append(f"{tag}:{i + 2}")

        # Add new column named "raw_row_id" with the generated row IDs at 0th index
        df.insert(0, "raw_row_id", row_ids)

        # Save individual sheet to a Parquet file
        file_name = f"raw_{tag}.parquet"

        file_path = STORE_DIR / file_name

        df.to_parquet(file_path, index=False)

        # Store row count
        row_counts[sheet_name] = len(df)
        print(f"{sheet_name}: {len(df):,} rows -> {file_name}")

        # Add to combined list
        all_data.append(df)

    # Combine both sheets
    combined_data = pd.concat(all_data, ignore_index=True)

    # Total row count
    row_counts["total"] = len(combined_data)

    # Save row counts in JSON
    manifest_path = STORE_DIR / "raw_manifest.json"

    with open(manifest_path, "w") as file:
        json.dump(row_counts, file, indent=2)

    print(f"Total rows read: {len(combined_data):,}")
    return combined_data

# 5. Run the program
if __name__ == "__main__":
    extract_raw()
    