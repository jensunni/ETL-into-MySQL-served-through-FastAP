""" Main script for the Online Retail ETL project"""
import json
from pathlib import Path

from pipeline.extract import extract_raw
from pipeline.clean import clean
from pipeline.load import load_to_mysql


# Project folder (based on the existing folder structure).
PROJECT_FOLDER = Path(__file__).resolve().parent.parent

# Folder for saved cleaning reports.
OUTPUT_FOLDER = PROJECT_FOLDER / "data" / "store"


def main():
    """Run all three ETL stages."""

    # PART 1: EXTRACT
    raw_data = extract_raw()
    print(f"Part 1 completed: {len(raw_data):,} rows extracted.")

    # PART 2: CLEAN
    fact_data, issue_data, cleaning_stats = clean(raw_data)

    # Create the output folder if it does not exist.
    OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)

    # Save cleaning statistics. This replaces the previous JSON file.
    stats_file = OUTPUT_FOLDER / "clean_stats.json"
    stats_file.write_text( json.dumps(cleaning_stats, indent=2), encoding="utf-8" )

    # Save data-quality issues. This replaces the previous CSV file.
    issues_file = OUTPUT_FOLDER / "issues.csv"
    issue_data.to_csv(issues_file, index=False)

    print("Part 2 completed: data cleaning finished.")
    print(json.dumps(cleaning_stats, indent=2))

    # PART 3: LOAD
    # The load_to_mysql function writes the data into MySQL.
    # Duplicate-row prevention is implemented inside that function.
    print("Part 3 started: loading data into MySQL...")

    row_counts = load_to_mysql(fact_data, issue_data)

    print("Part 3 completed: MySQL loading finished.")
    print("Rows in database tables:", row_counts)

# Start the ETL pipeline only when this file is run directly.
if __name__ == "__main__":
    main()
