""" Part 2: CLEAN THE DATA """
# decimal is for accurate financial calculations, such as prices, invoices, and revenue.
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import pandas as pd

# 1. PROJECT PATHS AND CONSTANTS

# Finding Project folder using Dynamic path allocation
ROOT = Path(__file__).resolve().parent.parent

# Reference files contain lookup information used during cleaning.
REF_DIR = ROOT / "data" / "reference"

# These are the original columns used to identify exact duplicates.
ORIGINAL_COLS = [
    "Invoice",
    "StockCode",
    "Description",
    "Quantity",
    "InvoiceDate",
    "Price",
    "Customer ID",
    "Country",
]

# Placeholder used when a customer ID is missing.
CASH_CUSTOMER_ID = "CASH_SALE"

# Money will be rounded to two decimal places.
CENT = Decimal("0.01")

# 2. SMALL HELPER FUNCTIONS

def create_issue_log(rows, rule, action, description):
    """ Finds which rows taken , which rule followed ,what action taken and description of the issue """
    return pd.DataFrame({ "rule": rule, "raw_row_id": rows["raw_row_id"].values, "action": action, "description": description})


def round_to_cents(value):
    """ Round the Decimal money value to two decimal places. """
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


# ============================================================
# R1. REMOVE EXACT DUPLICATES
# ============================================================

def r1_remove_duplicates(raw):
    """
    Compare the eight original columns.
        If all eight values are identical to an earlier row,
        keep the first row and drop the later duplicate.
    """
    duplicate_rows = raw.duplicated( subset=ORIGINAL_COLS, keep="first" )

    # Record every duplicate that will be removed.
    issues = create_issue_log( raw[duplicate_rows], "R1", "dropped", 
    "Exact duplicate of an earlier row < all 8 original columns identical >" )

    # Keep only rows that are not duplicates.
    cleaned = raw[~duplicate_rows].copy()

    return cleaned, issues

# PREPARE DATA TYPES

def prepare_types(df):
    """
    Rename columns and convert values into useful data types.
    This happens after Rule 1 so duplicate checking uses the original values.
    """
    prepared = pd.DataFrame({
        "raw_row_id": df["raw_row_id"],
        "source_sheet": df["source_sheet"],
        "invoice_no": df["Invoice"].str.strip(),
        "stock_code": df["StockCode"].str.strip(),
        "description": df["Description"],
        "quantity": pd.to_numeric(df["Quantity"]).astype("int64"),
        "unit_price": df["Price"].str.strip().map(Decimal),
        "invoice_date": pd.to_datetime(df["InvoiceDate"]),
        
        # It is found that customer ID contains decimal points should be removed
        "customer_raw": df["Customer ID"].str.strip().str.replace(r"\.0$", "", regex=True),
        "country_raw": df["Country"].str.strip(),
    })

    return prepared.reset_index(drop=True)


# ============================================================
# R2. IDENTIFY CANCELLATIONS AND WRITE-OFFS
# ============================================================

def r2_flag_cancellations_and_writeoffs(df):
    """
    Cancellation:
        Invoice number starts with C.
    Write-off:
        Quantity is negative, but the invoice is not a cancellation.
    """
    df = df.copy()

    # Convert invoice number to uppercase before checking its first letter.
    invoice_numbers = df["invoice_no"].str.strip().str.upper()
    df["is_cancellation"] = invoice_numbers.str.startswith("C")
    df["is_writeoff"] = ( (df["quantity"] < 0) & (~df["is_cancellation"]) )

    return df


# ============================================================
# R3. HANDLE MISSING CUSTOMER IDs
# ============================================================

def r3_handle_customers(df):
    """Replace blank customer IDs with the CASH_SALE placeholder."""
    df = df.copy()

    blank_customer = df["customer_raw"] == ""

    # True means the original customer ID was blank.
    df["is_cash_sale"] = blank_customer

    # Keep the original ID when available ; otherwise use CASH_SALE.
    df["customer_id"] = df["customer_raw"].where( ~blank_customer, CASH_CUSTOMER_ID )

    return df


# ============================================================
# R4. IDENTIFY NON-PRODUCT ITEMS
# ============================================================

def load_non_product_codes(file_path):
    """ Read the reference CSV and return its first column as a set of codes. """
    # keep_default_na=False ensures null values cannot be replaced by NaN
    codes_df = pd.read_csv( file_path, dtype=str, keep_default_na=False )
    # Take first column contain codes
    codes = set( codes_df.iloc[:, 0].str.strip().str.upper() )
    return codes


def r4_flag_non_products(df, non_product_codes):
    """ Flag stock codes that appear in the non-product reference list. """
    df = df.copy()
    df["is_non_product"] = ( df["stock_code"].str.upper().isin(non_product_codes) )
    return df


# ============================================================
# R5. IDENTIFY FREE SAMPLES AND NEGATIVE PRICES
# ============================================================

def r5_check_prices(df):
    """ Mark zero price items and negative-price items. """
    df = df.copy()
    df["is_free_sample"] = df["unit_price"] == 0
    df["is_negative_price"] = df["unit_price"] < 0
    return df


# ============================================================
# R6. CALCULATE GROSS AMOUNT
# ============================================================

def r6_calculate_exact_gross(df):
    """
    Calculate quantity multiplied by unit price.
        Keep the exact Decimal result for now.
        Rounding is done later, after currency conversion.
    """
    df = df.copy()
    df["gross_exact"] = [ Decimal(int(quantity)) * price for quantity, price in zip( df["quantity"], df["unit_price"] ) ]
    return df


# ============================================================
# R7. LOAD EXCHANGE RATES AND CONVERT CURRENCY
# ============================================================

def load_fx_rates(file_path):
    """ Read the first two CSV columns: date and GBP-to-USD exchange rate. """

    fx = pd.read_csv( file_path, dtype=str ).loc[:, ["rate_date", "rate"]]

    # Rename the columns to meaningful names.
    fx.columns = ["fx_rate_date", "fx_rate"]

    # Drop any rows that are missing either the date or the exchange rate.
    fx = fx.dropna()
    fx["fx_rate"] = fx["fx_rate"].map(Decimal)
    fx["fx_rate_date"] = ( pd.to_datetime(fx["fx_rate_date"]).astype("datetime64[ns]") )

    # There must be only one exchange rate per date.
    if fx["fx_rate_date"].duplicated().any():
        raise ValueError("fx file has duplicate dates")

    return fx.sort_values("fx_rate_date").reset_index(drop=True)


def r7_attach_exchange_rates(df, fx):
    """
    Attach the latest exchange rate on or before each invoice date.
        The join must not use a future exchange rate.
        The original row order is restored after the join.
    """
    original_row_count = len(df)

    df = df.copy()

    # Remove the time portion; keep only the calendar date.
    df["invoice_date"] = ( df["invoice_date"].dt.normalize().astype("datetime64[ns]") )

    # Save the original row position so we can restore it later.
    df["_order"] = range(original_row_count)

    # Both tables are matched using dates.
    merged = pd.merge_asof(
        df.sort_values("invoice_date", kind="stable"),
        fx,
        left_on="invoice_date",
        right_on="fx_rate_date",
        direction="backward",
    )

    # Restore the original row order.
    merged = ( merged.sort_values("_order").drop(columns="_order").reset_index(drop=True) )

    # Check that the join did not add or remove rows.
    if len(merged) != original_row_count:
        raise AssertionError( f" R7 changed row count : {original_row_count} -> {len(merged)} " )

    # Every invoice must have an exchange rate.
    if merged["fx_rate"].isna().any():
        raise ValueError( " Some invoice dates have no earlier FX rate - check the fx file range ")

    # Convert exchange rates from strings to Decimal values.
    merged["fx_rate"] = merged["fx_rate"].map(Decimal)

    return merged


def round_money_values(df):
    """Round GBP and USD amounts to two decimal places."""
    df = df.copy()

    df["gross_gbp"] = df["gross_exact"].map(round_to_cents)
    df["gross_usd"] = [ round_to_cents(gross * rate) for gross, rate in zip(df["gross_exact"], df["fx_rate"]) ]

    # The exact intermediate amount is no longer needed.
    return df.drop(columns="gross_exact")


# ============================================================
# R8. MAP COUNTRIES TO COUNTRIES AND REGIONS
# ============================================================

def r8_add_country_and_region(df, file_path):
    """Use the country reference file to add tidy country and region names."""
    country_map = pd.read_csv( file_path, dtype=str, keep_default_na=False ).iloc[:, :3]

    country_map.columns = ["country_raw", "country", "region"]
    country_map["country_raw"] = country_map["country_raw"].str.strip()

    # Each original country value must appear only once in the mapping file.
    if country_map["country_raw"].duplicated().any():
        raise ValueError(" country_region.csv has duplicate Country values ")

    original_row_count = len(df)

    # Left join keeps all rows from the sales data.
    result = df.merge( country_map, how="left", on="country_raw" )

    if len(result) != original_row_count:
        raise AssertionError("R8 changed row count")

    # Stop if a country is missing from the mapping file.
    unmapped_countries = ( result.loc[result["country"].isna(), "country_raw"].unique() )

    if len(unmapped_countries) > 0:
        raise ValueError( f" Country values missing from country_region.csv : {list(unmapped_countries)} " )

    return result


# ============================================================
# MAIN CLEANING PIPELINE
# ============================================================

def clean(raw):
    """
    Run all cleaning rules from Rule 1 to Rule 8.
    """

    stats = {"rows_read": len(raw)}
    issue_tables = []

    # --------------------------------------------------------
    # R1. Remove exact duplicates
    # --------------------------------------------------------
    df, issues = r1_remove_duplicates(raw)
    issue_tables.append(issues)

    stats["r1_duplicates_removed"] = len(raw) - len(df)

    # Convert columns to their required data types.
    df = prepare_types(df)

    # --------------------------------------------------------
    # R2. Identify cancellations and write-offs
    # --------------------------------------------------------
    df = r2_flag_cancellations_and_writeoffs(df)

    stats["r2_cancellation_lines"] = int(df["is_cancellation"].sum())
    stats["r2_negative_qty_not_cancellation"] = int(df["is_writeoff"].sum())

    stats["r2_cancellation_with_positive_qty"] = int( (df["is_cancellation"] & (df["quantity"] > 0)).sum() )

    issue_tables.append(create_issue_log(
        df[df["is_cancellation"]],
        "R2",
        "flagged",
        "Cancellation: invoice number starts with C"
    ))

    issue_tables.append(create_issue_log(
        df[df["is_writeoff"]],
        "R2",
        "flagged",
        "Stock write-off: negative quantity on a non-cancellation invoice"
    ))

    # --------------------------------------------------------
    # R3. Handle missing customer IDs
    # --------------------------------------------------------
    df = r3_handle_customers(df)

    stats["r3_cash_sale_lines"] = int(df["is_cash_sale"].sum())

    issue_tables.append(create_issue_log(
        df[df["is_cash_sale"]],
        "R3",
        "changed",
        f"Blank Customer ID replaced with placeholder {CASH_CUSTOMER_ID}"
    ))

    # --------------------------------------------------------
    # R4. Identify non-product items
    # --------------------------------------------------------
    non_product_file = REF_DIR / "non_product_codes.csv"
    non_product_codes = load_non_product_codes(non_product_file)

    df = r4_flag_non_products(df, non_product_codes)

    stats["r4_non_product_lines"] = int(df["is_non_product"].sum())

    issue_tables.append(create_issue_log(
        df[df["is_non_product"]],
        "R4",
        "flagged",
        "Non-product stock code (postage/fee/adjustment); excluded from product revenue"
    ))

    # --------------------------------------------------------
    # R5. Check prices
    # --------------------------------------------------------
    df = r5_check_prices(df)

    stats["r5_free_sample_lines"] = int(df["is_free_sample"].sum())
    stats["r5_negative_price_rejected"] = int(df["is_negative_price"].sum())

    stats["r4_and_r5_negative_overlap"] = int( (df["is_non_product"] & df["is_negative_price"]).sum() )

    issue_tables.append(create_issue_log(
        df[df["is_free_sample"]],
        "R5",
        "flagged",
        "Zero price: free sample, kept but not counted as revenue"
    ))

    issue_tables.append(create_issue_log(
        df[df["is_negative_price"]],
        "R5",
        "rejected",
        "Negative price: rejected, not loaded into the fact table"
    ))

    # Remove rows with negative prices.
    df = df[~df["is_negative_price"]].reset_index(drop=True)

    # --------------------------------------------------------
    # R6. Calculate exact gross amount
    # --------------------------------------------------------
    df = r6_calculate_exact_gross(df)

    # --------------------------------------------------------
    # R7. Attach exchange rates and convert currency
    # --------------------------------------------------------
    fx_file = REF_DIR / "fx_rates_gbp_usd.csv"
    fx = load_fx_rates(fx_file)

    rows_before_fx = len(df)
    df = r7_attach_exchange_rates(df, fx)

    stats["r7_rows_before_fx"] = rows_before_fx
    stats["r7_rows_after_fx"] = len(df)

    stats["r7_rows_using_earlier_rate"] = int( (df["invoice_date"] != df["fx_rate_date"]).sum() )

    df = round_money_values(df)

    # --------------------------------------------------------
    # R8. Add country and region
    # --------------------------------------------------------
    country_file = REF_DIR / "country_region.csv"
    df = r8_add_country_and_region(df, country_file)

    unknown_country = df["country"] == "Unknown"

    stats["r8_unknown_country_lines"] = int(unknown_country.sum())

    issue_tables.append(create_issue_log(
        df[unknown_country],
        "R8",
        "flagged",
        "Country maps to Unknown; kept as Unknown, not guessed"
    ))

    # --------------------------------------------------------
    # Final business rule: identify product revenue
    # --------------------------------------------------------
    # Cancellations remain in the data as negative revenue.
    # Non-products and free samples are not product revenue.
    df["is_product_revenue"] = (
        ~df["is_non_product"]
        & ~df["is_free_sample"]
    )

    # Combine all issue tables into one DataFrame.
    issues = pd.concat(issue_tables, ignore_index=True)

    # --------------------------------------------------------
    # Create summary statistics
    # --------------------------------------------------------
    stats["fact_rows"] = len(df)

    stats["distinct_customers_excl_cash"] = int( df.loc[~df["is_cash_sale"], "customer_id"].nunique() )

    # Decimal(0) ensures totals are calculated using Decimal values.
    zero = Decimal(0)

    # Calculate totals for all rows and product-revenue rows.
    for label, row_filter in [("all_lines", slice(None)), ("product_only", df["is_product_revenue"])]:

        stats[f"total_gbp_{label}"] = str( sum(df.loc[row_filter, "gross_gbp"], zero) )

        stats[f"total_usd_{label}"] = str( sum(df.loc[row_filter, "gross_usd"], zero) )

    # Count how many issue records belong to each rule.
    stats["issues_per_rule"] = {rule: int(count) for rule, count in ( issues["rule"].value_counts().sort_index().items())}

    # Keep only the final columns required in the fact table.
    fact_columns = [
        "raw_row_id",
        "source_sheet",
        "invoice_no",
        "stock_code",
        "description",
        "quantity",
        "unit_price",
        "invoice_date",
        "customer_id",
        "is_cash_sale",
        "country",
        "region",
        "is_cancellation",
        "is_writeoff",
        "is_non_product",
        "is_free_sample",
        "is_product_revenue",
        "gross_gbp",
        "fx_rate",
        "fx_rate_date",
        "gross_usd",
    ]

    fact_df = df[fact_columns]

    return fact_df, issues, stats
