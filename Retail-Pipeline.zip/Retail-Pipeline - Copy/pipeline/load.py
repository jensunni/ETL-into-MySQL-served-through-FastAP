"""PART 3: Load MySQL"""
import os
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL, make_url

# -------------------------pre-request-------------------------
ROOT = Path(__file__).resolve().parent.parent
SCHEMA_FILE = ROOT / "sql" / "schema.sql"
DEFAULT_URL = "mysql+pymysql://root:root@localhost:3306/retail_sales"


# -------------------------connection--------------------------
def get_url():
    return make_url(os.getenv("MYSQL_URL", DEFAULT_URL))


def get_engine():
    return create_engine(get_url(), pool_pre_ping=True)


def ensure_database():
    url = get_url()

    server_url = URL.create(drivername=url.drivername, username=url.username, password=url.password,
    host=url.host, port=url.port, query=url.query)

    server = create_engine(server_url)
    with server.begin() as conn:
        conn.execute(text(f"CREATE DATABASE IF NOT EXISTS `{url.database}` CHARACTER SET utf8mb4"))

    server.dispose()


def run_schema(engine):
    lines = [l for l in SCHEMA_FILE.read_text().splitlines() if not l.strip().startswith("--")]
    statements = [s.strip() for s in "\n".join(lines).split(";") if s.strip()]
    with engine.begin() as conn:
        for stmt in statements:
            conn.execute(text(stmt))


# ------------------------build the tables---------------------------------------------
def _add_keys(df: pd.DataFrame, key_name: str) -> pd.DataFrame:
    df = df.reset_index(drop=True)
    df.insert(0, key_name, range(1, len(df) + 1))
    return df


def build_tables(fact: pd.DataFrame, issues: pd.DataFrame) -> dict:
    """Pure pandas: turn the cleaned fact into dimension tables + the final fact table."""
    fact = fact.copy()
    # MySQL's default collation ignores case, so 'abc' and 'ABC' would collide on a
    # unique key. Normalise stock codes to upper case (same idea as R4).
    fact["stock_code_norm"] = fact["stock_code"].str.upper()

    # ---- dim_country-------------------------------------------------------------------
    dim_country = _add_keys(
        fact[["country", "region"]].drop_duplicates().sort_values(["country", "region"]), 
        "country_key").rename(columns={"country": "country_name"})
    country_lookup = dim_country.rename(columns={"country_name": "country"})

    # ---- dim_customer (country = country on the customer's most recent line)
    latest = (fact.sort_values("invoice_date", kind="stable").groupby("customer_id").tail(1)
            [["customer_id", "is_cash_sale", "country", "region"]].sort_values("customer_id"))
    
    dim_customer = latest.merge(country_lookup, on=["country", "region"], how="left")
    dim_customer.loc[dim_customer["is_cash_sale"], "country_key"] = None   # meaningless for cash sales
    dim_customer = _add_keys(dim_customer[["customer_id", "is_cash_sale", "country_key"]],"customer_key")
    dim_customer["country_key"] = (dim_customer["country_key"].astype("Int64").astype(object).where(dim_customer["country_key"].notna(), None))

    # ---- dim_product (description = most common non-blank description for the code)
    def pick_description(s: pd.Series):
        counts = s.str.strip().value_counts().sort_index()
        return counts.sort_values(ascending=False, kind="stable").index[0]

    non_blank = fact[fact["description"].str.strip() != ""]
    descriptions = non_blank.groupby("stock_code_norm")["description"].agg(pick_description)

    products = (fact.groupby("stock_code_norm")["is_non_product"].max().rename("is_non_product").reset_index().sort_values("stock_code_norm"))

    products["description"] = products["stock_code_norm"].map(descriptions)
    products["description"] = products["description"].astype(object).where(products["description"].notna(), None)

    dim_product = _add_keys(products.rename(columns={"stock_code_norm": "stock_code"})[["stock_code", "description", "is_non_product"]],"product_key")

    # ---- dim_date (every day in range, so weekends exist too)----------------------------------------------
    days = pd.date_range(fact["invoice_date"].min(), fact["invoice_date"].max(), freq="D")
    dim_date = pd.DataFrame({
        "date_key": days.strftime("%Y%m%d").astype(int),
        "full_date": days.date,
        "year": days.year,
        "month": days.month,
        "year_month": days.year * 100 + days.month,
        "day": days.day,
        "day_name": days.day_name(),
        "is_weekend": days.dayofweek >= 5,
    })

    # ---- fact: replace natural keys with surrogate keys---------------------------------------------------
    n = len(fact)
    fact = fact.merge(country_lookup, on=["country", "region"], how="left")

    fact["customer_key"] = fact["customer_id"].map(dict(zip(dim_customer["customer_id"], dim_customer["customer_key"])))

    fact["product_key"] = fact["stock_code_norm"].map(dict(zip(dim_product["stock_code"], dim_product["product_key"])))

    fact["date_key"] = fact["invoice_date"].dt.strftime("%Y%m%d").astype(int)
    fact["fx_rate_date"] = fact["fx_rate_date"].dt.date

    for col in ["customer_key", "product_key", "country_key"]:
        if fact[col].isna().any():
            raise ValueError(f"Fact rows without a {col} - dimension lookup failed")
    if len(fact) != n:
        raise AssertionError("Fact row count changed while adding keys")

    fact_out = fact[[
        "raw_row_id", "source_sheet", "invoice_no", "date_key", "customer_key",
        "product_key", "country_key", "quantity", "unit_price", "gross_gbp",
        "fx_rate", "fx_rate_date", "gross_usd", "is_cancellation", "is_writeoff",
        "is_non_product", "is_free_sample", "is_product_revenue",
    ]]
    return {
        "dim_country": dim_country, "dim_customer": dim_customer,
        "dim_product": dim_product, "dim_date": dim_date,
        "fact_invoice_line": fact_out,
        "data_quality_issue": issues[["rule", "raw_row_id", "action", "description"]],
    }


# ------------------------------------load-----------------------------------------------------------
INSERT_CHUNK = 5000


def insert_dataframe(connection, table_name: str, df: pd.DataFrame) -> None:
    """Insert a DataFrame into a MySQL table using plain SQLAlchemy """
    if df.empty:
        return
    columns = list(df.columns)
    column_list = ", ".join(f"`{name}`" for name in columns)
    value_list = ", ".join(f":{name}" for name in columns)
    statement = text(f"INSERT INTO `{table_name}` ({column_list}) VALUES ({value_list})")

    for start in range(0, len(df), INSERT_CHUNK):
        chunk = df.iloc[start:start + INSERT_CHUNK]
        # plain Python values; missing values become None (SQL NULL)
        chunk = chunk.astype(object).where(chunk.notna(), None)
        connection.execute(statement, chunk.to_dict("records"))


LOAD_ORDER = ["dim_country", "dim_customer", "dim_product", "dim_date", "fact_invoice_line", "data_quality_issue"]


def load_to_mysql(fact: pd.DataFrame, issues: pd.DataFrame) -> dict:
    tables = build_tables(fact, issues)

    ensure_database()
    engine = get_engine()
    run_schema(engine)                       # drop + create = safe to rerun

    with engine.begin() as conn:             # one transaction: all rows or none
        for name in LOAD_ORDER:
            df = tables[name]
            insert_dataframe(conn, name, df)
            print(f"  loaded {name}: {len(df):,} rows")

    # Verify what is really in MySQL
    with engine.connect() as conn:
        counts = {name: conn.execute(text(f"SELECT COUNT(*) FROM {name}")).scalar()
                  for name in LOAD_ORDER}
        gbp = conn.execute(text("SELECT SUM(gross_gbp) FROM fact_invoice_line")).scalar()
    for name in LOAD_ORDER:
        if counts[name] != len(tables[name]):
            raise AssertionError(f"{name}: loaded {len(tables[name])} but MySQL has {counts[name]}")
    expected_gbp = sum(tables["fact_invoice_line"]["gross_gbp"])
    if gbp != expected_gbp:
        raise AssertionError(f"GBP total mismatch: MySQL {gbp} vs pandas {expected_gbp}")
    print(f"  verified: counts match, total GBP = {gbp}")
    engine.dispose()
    return counts
