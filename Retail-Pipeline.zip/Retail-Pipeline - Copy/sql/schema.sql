-- Star schema for the Retail Sales pipeline (MySQL 8, InnoDB)
-- Re-runnable: tables are dropped and recreated, so every run starts clean.
-- Note: keep semicolons ONLY at the end of statements (load.py splits on them).
-- Note: year_month is a RESERVED WORD in MySQL, so it is written in backticks below.

DROP TABLE IF EXISTS fact_invoice_line;
DROP TABLE IF EXISTS data_quality_issue;
DROP TABLE IF EXISTS dim_customer;
DROP TABLE IF EXISTS dim_product;
DROP TABLE IF EXISTS dim_date;
DROP TABLE IF EXISTS dim_country;

CREATE TABLE dim_country (
    country_key   INT          NOT NULL,
    country_name  VARCHAR(100) NOT NULL,
    region        VARCHAR(50)  NOT NULL,
    PRIMARY KEY (country_key),
    UNIQUE KEY uq_country (country_name, region)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE dim_customer (
    customer_key  INT         NOT NULL,
    customer_id   VARCHAR(20) NOT NULL,
    is_cash_sale  TINYINT(1)  NOT NULL DEFAULT 0,
    country_key   INT         NULL,
    PRIMARY KEY (customer_key),
    UNIQUE KEY uq_customer_id (customer_id),
    CONSTRAINT fk_customer_country FOREIGN KEY (country_key) REFERENCES dim_country (country_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE dim_product (
    product_key    INT          NOT NULL,
    stock_code     VARCHAR(30)  NOT NULL,
    description    VARCHAR(255) NULL,
    is_non_product TINYINT(1)   NOT NULL DEFAULT 0,
    PRIMARY KEY (product_key),
    UNIQUE KEY uq_stock_code (stock_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE dim_date (
    date_key    INT         NOT NULL,
    full_date   DATE        NOT NULL,
    year        SMALLINT    NOT NULL,
    month       TINYINT     NOT NULL,
    `year_month` INT        NOT NULL,
    day         TINYINT     NOT NULL,
    day_name    VARCHAR(10) NOT NULL,
    is_weekend  TINYINT(1)  NOT NULL,
    PRIMARY KEY (date_key),
    UNIQUE KEY uq_full_date (full_date),
    KEY idx_year_month (`year_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE fact_invoice_line (
    raw_row_id         VARCHAR(20)   NOT NULL,
    source_sheet       VARCHAR(20)   NOT NULL,
    invoice_no         VARCHAR(20)   NOT NULL,
    date_key           INT           NOT NULL,
    customer_key       INT           NOT NULL,
    product_key        INT           NOT NULL,
    country_key        INT           NOT NULL,
    quantity           INT           NOT NULL,
    unit_price         DECIMAL(12,4) NOT NULL,
    gross_gbp          DECIMAL(14,2) NOT NULL,
    fx_rate            DECIMAL(12,6) NOT NULL,
    fx_rate_date       DATE          NOT NULL,
    gross_usd          DECIMAL(14,2) NOT NULL,
    is_cancellation    TINYINT(1)    NOT NULL,
    is_writeoff        TINYINT(1)    NOT NULL,
    is_non_product     TINYINT(1)    NOT NULL,
    is_free_sample     TINYINT(1)    NOT NULL,
    is_product_revenue TINYINT(1)    NOT NULL,
    PRIMARY KEY (raw_row_id),
    KEY idx_fact_date (date_key),
    KEY idx_fact_customer (customer_key),
    KEY idx_fact_product (product_key, date_key),
    KEY idx_fact_country (country_key),
    KEY idx_fact_invoice (invoice_no),
    CONSTRAINT fk_fact_date     FOREIGN KEY (date_key)     REFERENCES dim_date (date_key),
    CONSTRAINT fk_fact_customer FOREIGN KEY (customer_key) REFERENCES dim_customer (customer_key),
    CONSTRAINT fk_fact_product  FOREIGN KEY (product_key)  REFERENCES dim_product (product_key),
    CONSTRAINT fk_fact_country  FOREIGN KEY (country_key)  REFERENCES dim_country (country_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE data_quality_issue (
    issue_id     BIGINT       NOT NULL AUTO_INCREMENT,
    rule         VARCHAR(5)   NOT NULL,
    raw_row_id   VARCHAR(20)  NOT NULL,
    action       VARCHAR(20)  NOT NULL,
    description  VARCHAR(255) NOT NULL,
    PRIMARY KEY (issue_id),
    KEY idx_issue_rule (rule),
    KEY idx_issue_row (raw_row_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
